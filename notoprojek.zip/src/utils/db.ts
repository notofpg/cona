const DB_NAME = 'tata-large-storage';
const DB_VERSION = 1;
const STORE_NAME = 'large-items';
const LARGE_PREFIX = 'tata_large_';

const LARGE_STORAGE_KEYS: string[] = [];
const LEGACY_STORAGE_MAP: Record<string, string> = {};
const memoryCache = new Map<string, unknown>();
const existingDataKeys = new Set<string>();
let storageHydrated = false;

export async function requestPersistentStorage(): Promise<boolean> {
  if (typeof navigator === 'undefined' || !('storage' in navigator) || !('persist' in navigator.storage)) {
    return false;
  }

  try {
    return await navigator.storage.persist();
  } catch {
    return false;
  }
}

export function setStorageHydrated(value: boolean): void {
  storageHydrated = value;
}

export function isStorageHydrated(): boolean {
  return storageHydrated;
}

export function hasMeaningfulValue(value: unknown): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === 'string') return value.length > 0;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'object') return Object.keys(value as Record<string, unknown>).length > 0;
  return true;
}

function getStorage(): Storage | null {
  if (typeof window === 'undefined') return null;

  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function getStorageKey(key: string): string {
  return `${LARGE_PREFIX}${key}`;
}

export async function getDB(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    throw new Error('IndexedDB is unavailable in this browser context.');
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'));
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

export function getLargeItemSync<T>(key: string, fallback: T | null = null): T | null {
  if (memoryCache.has(key)) {
    return memoryCache.get(key) as T;
  }

  const storage = getStorage();
  if (!storage) return fallback;

  try {
    const raw = storage.getItem(getStorageKey(key));
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as T;
    memoryCache.set(key, parsed);
    return parsed;
  } catch {
    return fallback;
  }
}

export async function getLargeItem<T>(key: string, fallback: T | null = null): Promise<T | null> {
  const syncValue = getLargeItemSync<T>(key, fallback);
  if (syncValue !== null && syncValue !== undefined) {
    return syncValue;
  }

  try {
    const db = await getDB();
    return await new Promise<T | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.get(key);

      request.onsuccess = () => {
        const value = request.result as T | undefined;
        if (value !== undefined) {
          memoryCache.set(key, value);
          resolve(value);
        } else {
          resolve(fallback);
        }
      };

      request.onerror = () => reject(request.error ?? new Error(`Failed to read large item: ${key}`));
      tx.onerror = () => reject(tx.error ?? new Error(`Failed to read large item: ${key}`));
    });
  } catch {
    return fallback;
  }
}

export async function setLargeItem<T>(key: string, value: T): Promise<void> {
  memoryCache.set(key, value);
  existingDataKeys.add(key);

  const storage = getStorage();
  if (storage) {
    try {
      storage.setItem(getStorageKey(key), JSON.stringify(value));
    } catch {
      // ignore restricted-environment storage failures
    }
  }

  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.put(value, key);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error(`Failed to write large item: ${key}`));
      tx.onerror = () => reject(tx.error ?? new Error(`Failed to write large item: ${key}`));
    });
  } catch {
    // ignore write failures in restricted environments
  }
}

export async function deleteLargeItem(key: string): Promise<void> {
  memoryCache.delete(key);
  existingDataKeys.delete(key);

  const storage = getStorage();
  if (storage) {
    try {
      storage.removeItem(getStorageKey(key));
    } catch {
      // ignore removal failures
    }
  }

  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.delete(key);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error(`Failed to delete large item: ${key}`));
      tx.onerror = () => reject(tx.error ?? new Error(`Failed to delete large item: ${key}`));
    });
  } catch {
    // ignore deletion failures in restricted environments
  }
}

export async function clearAllLargeItems(): Promise<void> {
  memoryCache.clear();
  existingDataKeys.clear();

  const storage = getStorage();
  if (storage) {
    const keysToRemove: string[] = [];
    for (let i = 0; i < storage.length; i += 1) {
      const key = storage.key(i);
      if (key && key.startsWith(LARGE_PREFIX)) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach((key) => storage.removeItem(key));
  }

  try {
    const db = await getDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error('Failed to clear all large items'));
      tx.onerror = () => reject(tx.error ?? new Error('Failed to clear all large items'));
    });
  } catch {
    // ignore clear failures in restricted environments
  }
}

export async function getAllLargeItemsByPrefix(prefix: string): Promise<Record<string, unknown>> {
  const result: Record<string, unknown> = {};

  for (const key of Array.from(memoryCache.keys())) {
    if (key.startsWith(prefix)) {
      result[key] = memoryCache.get(key);
    }
  }

  const storage = getStorage();
  if (storage) {
    for (let i = 0; i < storage.length; i += 1) {
      const key = storage.key(i);
      if (!key || !key.startsWith(LARGE_PREFIX + prefix)) continue;
      const realKey = key.slice(LARGE_PREFIX.length);
      try {
        const raw = storage.getItem(key);
        if (raw) result[realKey] = JSON.parse(raw);
      } catch {
        // ignore malformed values
      }
    }
  }

  return result;
}

export async function setManyLargeItems(items: Record<string, unknown>): Promise<void> {
  for (const [key, value] of Object.entries(items)) {
    await setLargeItem(key, value);
  }
}

export async function checkAndMigrateFromLocalStorage(
  key: string,
  legacyKey: string | undefined,
  store: IDBObjectStore,
  finishKey: () => void
): Promise<void> {
  const storage = getStorage();
  if (!storage) {
    finishKey();
    return;
  }

  const candidateKey = legacyKey ?? getStorageKey(key);
  const raw = storage.getItem(candidateKey);
  if (!raw) {
    finishKey();
    return;
  }

  try {
    const value = JSON.parse(raw);
    memoryCache.set(key, value);
    if (hasMeaningfulValue(value)) existingDataKeys.add(key);
    store.put(value, key);
    if (candidateKey !== getStorageKey(key)) {
      storage.removeItem(candidateKey);
    }
  } catch {
    // ignore malformed migration payloads
  }

  finishKey();
}

export async function preloadLargeItems(): Promise<{ success: boolean; migratedCount: number; error?: unknown }> {
  try {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      setStorageHydrated(true);
      return { success: true, migratedCount: 0 };
    }

    requestPersistentStorage().catch(() => {});

    const db = await getDB();
    let migratedCount = 0;

    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      let completed = 0;
      const total = LARGE_STORAGE_KEYS.length || 0;

      const finishKey = () => {
        completed += 1;
        if (completed >= total) {
          resolve();
        }
      };

      if (total === 0) {
        resolve();
        return;
      }

      for (const key of LARGE_STORAGE_KEYS) {
        const request = store.get(key);

        request.onsuccess = () => {
          let val = request.result;
          if (val) {
            memoryCache.set(key, val);
            if (hasMeaningfulValue(val)) {
              existingDataKeys.add(key);
            }
            finishKey();
          } else {
            const legacyKey = LEGACY_STORAGE_MAP[key];
            if (legacyKey) {
              const legacyReq = store.get(legacyKey);
              legacyReq.onsuccess = () => {
                if (legacyReq.result) {
                  val = legacyReq.result;
                  memoryCache.set(key, val);
                  if (hasMeaningfulValue(val)) {
                    existingDataKeys.add(key);
                  }
                  store.put(val, key);
                  migratedCount += 1;
                  finishKey();
                  return;
                }
                checkAndMigrateFromLocalStorage(key, legacyKey, store, finishKey).catch(() => {});
              };
              legacyReq.onerror = () => {
                checkAndMigrateFromLocalStorage(key, legacyKey, store, finishKey).catch(() => {});
              };
            } else {
              checkAndMigrateFromLocalStorage(key, undefined, store, finishKey).catch(() => {});
            }
          }
        };

        request.onerror = () => {
          const legacyKey = LEGACY_STORAGE_MAP[key];
          checkAndMigrateFromLocalStorage(key, legacyKey, store, finishKey).catch(() => {});
        };
      }

      transaction.onerror = (e) => {
        console.error('[Tata Storage] Transaction error during preload:', e);
        reject(e);
      };
    });

    setStorageHydrated(true);
    return { success: true, migratedCount };
  } catch (e) {
    console.warn('[Tata Storage] IndexedDB preload unavailable, continuing in degraded storage mode:', e);
    setStorageHydrated(true);
    return { success: true, migratedCount: 0, error: e };
  }
}

export default {
  requestPersistentStorage,
  getDB,
  getLargeItem,
  getLargeItemSync,
  setLargeItem,
  deleteLargeItem,
  clearAllLargeItems,
  getAllLargeItemsByPrefix,
  setManyLargeItems,
  isStorageHydrated,
  preloadLargeItems,
};
