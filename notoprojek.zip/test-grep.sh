grep -rn "geminiApiKey" src/
